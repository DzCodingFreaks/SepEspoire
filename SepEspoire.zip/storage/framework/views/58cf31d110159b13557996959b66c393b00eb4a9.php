<!-- Intro Title Section 1 -->
<div class="section-block intro-title-1 small bkg-gradient-custom-blue color-white">
    <div class="row">
        <div class="column width-12">
            <div class="title-container">
                <div class="title-container-inner">
                    <div class="row flex">
                        <div class="column width-6 v-align-middle">
                            <div>
                                <h1 class="mb-0">About Us</h1>
                                <p class="lead mb-0 mb-mobile-20">A five individual team</p>
                            </div>
                        </div>
                        <div class="column width-6 v-align-middle">
                            <div>
                                <ul class="breadcrumb inline-block mb-0 pull-right clear-float-on-mobile">
                                    <li>
                                        <a href="index.html">Home</a>
                                    </li>
                                    <li>
                                        About Us
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Intro Title Section 1 End -->